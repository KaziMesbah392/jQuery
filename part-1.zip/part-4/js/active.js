$(document).ready(function(){
$("#fade").click(function(){
	$("#one").fadeIn(2000);
});
$("#fadeout").click(function(){
	$("#one").fadeOut(2000);
});
});