jquery ja korte pare ta holo,,,,
	1-click
	2-double click(dblclick)
	3-mouseover
	4-mouseout
ai event gulo diye jquery kore dite pare ,,,,,,
	1- hide (লুকিয়ে ফেলে)
	2- ‍show (দেখানো)
	3- fadeIn (আবছা হয়ে ফিরে আসবে)
	4- fadeOut (আবছা হয়ে হারিয়ে যাবে)
	5- ‍slideUP (নিছে থেকে উঠবে)
	6- slideDown (উপর থেকে উঠবে)
	
Jquery lekhar niom,,,,
	$(document).ready(function(){
	
	});
	
	
	
	
function gular kaj,,,,,,,,,,,,,

$(document).ready(function(){
	
$("#hide").click(function(){
	$(".first").hide(2000);
});
// 1 click hide korte ai function aibabe bebohar korte hoy 



$("#show").click(function(){
$(".first").show(5000);
});

// 1click a hide kora jinis ke ai function dara show kora hoy
	



	
$("#hide").dblclick(function(){
	$(".first").hide(5000);
});
// dblclick click hide korte ai function aibabe bebohar korte hoy 


$("#show").dblclick(function(){
	$(".first").show(2000);
});

// dblclick click show korte ai function aibabe bebohar korte hoy

	

	
	
	
$("#hide").mouseover(function(){
	$(".first").hide(5000);
});
// mouseover korle hide korte ai function aibabe bebohar korte hoy 


$("#show").mouseover     (function(){
	$(".first").show(2000);
});

// mouseover korle show korte ai function aibabe bebohar korte hoy

	
	
$("#hide").mouseout(function(){
	$(".first").hide(5000);
});
// mouseout korle hide korte ai function aibabe bebohar korte hoy 


$("#show").mouseout(function(){
	$(".first").show(2000);
});

// mouseout korle show korte ai function aibabe bebohar korte hoy

	
});