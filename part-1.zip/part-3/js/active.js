$(document).ready(function(){
$("#slide").mouseover(function(){
	$("#one").slideToggle(2000);	
	});
});