ai part3 slideUp slideDown etc er kaj korbo,,,,

$(document).ready(function(){
$("#down").click(function(){
	$("#one").slideDown(2000);
});

bislesion: akhane down name id ke jokhon click kora hobe tokhon one name id ta slideDown hobe,


$("#up").click(function(){
	$("#one").slideUp(2000);
});	
bislesion: akhane up name id ke jokhon click kora hobe tokhon one name id ta slideDown hobe,
	
});
''''''''''''''''''
amra age jemon korecilam thik temni bhabe amra 1ta button er moddhe kaj korte parbo tar jonno amra age toggle name 1ta event use kore cilam thik akhon o amra toggle name function use korbo tar jonno use korbo 
slideToggle

use korle dui ti button lagbe na 1ta kaj hoye jabe,,,,,,
therefore mouseover and mouseout and dblclick etc use korte parbo........



-=------- The End ------------