jequery toggle er kaj dekhbo,,,,


toggle mane holo amra part one je bhabe show abong hide korecilam tokhon kinto amra duita button er moddhe kaj korecilam ekta holo on r 1 ta holo of akhon toggle ekshate duita kaj kore on and off 