$(document).ready(function(){
$("#showhide").click(function(){
	$(".first").toggle(2000);
});
	
	
	
});