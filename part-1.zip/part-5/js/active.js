$(document).ready(function(){
$("#fade").click(function(){
	$("#one").slideUp(2000);
});

$("#stop").click(function(){
	$("#one").stop();
});
});