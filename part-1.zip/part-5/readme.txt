ai part-5 ami skhbo kivabe slide out/in ke stop korte hoy tar jonno ja korte hobe ta holo,,,,,,,,
sorboda mone rakhte hobe je kokhono amra 1namer value 2 ba tar odik use korte parbo na
